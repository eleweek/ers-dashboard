<?php namespace CharityPressDonations\Library;

class Email {

	public function init() {
		add_filter( 'wp_mail_content_type', [ $this, 'set_content_type' ] );
		add_action( 'admin_post_charitypress_complete_donation', [ $this, 'process' ] );
		add_action( 'admin_post_nopriv_charitypress_complete_donation', [ $this, 'process' ] );

		// remove when done
		add_action( 'phpmailer_init', [ $this, 'mailtrap' ] );
	}

	/**
	 * Set the content type of the email
	 *
	 * @param $content_type
	 *
	 * @return string
	 */
	public function set_content_type( $content_type ) {
		return 'text/html';
	}

	/**
	 * Handles the form submission, email sending and redirect.
	 *
	 * @param Transaction $transaction
	 */
	public function process( Transaction $transaction ) {

		if ( ! $this->transactionSuccessAndHaveDonorEmail( $transaction ) ) {
			exit();
		}
		$this->sendMail( $transaction );
		wp_redirect( '/' );
		exit();
	}

	/**
	 * @param Transaction $transaction
	 */
	public function sendMail( Transaction $transaction ) {
		$to      = $this->getEmail( $transaction->getDonor() );
		$subject = $this->getSubject();
		$body    = $this->getBody( $transaction->toArray() );
		$headers = $this->applyHeaders();
		wp_mail( $to, $subject, $body, $headers );
	}

	/**
	 * @param $donor
	 *
	 * @return null|string
	 */
	private function getEmail( $donor ) {
		if ( $donor !== null && ! array_key_exists( 'email', $donor ) ) {
			return false;
		}

		return $donor['email'];
	}

	/**
	 * @return null
	 */
	private function getSubject() {
		$subject = get_option( 'cp_donations_email_confirmation_subject' );
		if ( $subject === false ) {
			return null;
		}

		return $subject;
	}

	/**
	 * @param array $transaction
	 *
	 * @return string
	 */
	private function getBody( array $transaction ) {
		$template = get_stylesheet_directory() . '/charitypress_donations/email-confirmation.php';

		return $this->compile( $transaction, $template );
	}


	/**
	 * Fill in the given template with the posted form variables and return
	 * the compiled form.
	 *
	 * @param array $input Array of post input
	 * @param string $template Path to the template
	 *
	 * @return string Compiled template
	 */
	public function compile( $input, $template ) {
		ob_start();

		extract( $input, EXTR_OVERWRITE );
		include $template;

		$content = ob_get_contents();
		ob_end_clean();

		return $content;
	}

	/**
	 * @param Transaction $transaction
	 *
	 * @return bool
	 */
	private function transactionSuccessAndHaveDonorEmail( Transaction $transaction ) {
		if ( $transaction->getStatus() !== 'success' ) {
			return false;
		}

		$to = $this->getEmail( $transaction->getDonor() );
		if ( ! $to ) {
			return false;
		}

		return true;
	}


	/**
	 * @return array
	 */
	private function applyHeaders() {
		$headers = [ ];
		if ( $bcc = $this->getBcc() ) {
			$headers[] = 'Bcc:' . $bcc;
		}

		if ( $from = $this->getFrom() ) {
			$headers[] = 'From: ' . get_bloginfo( 'name' ) . '<' . $from . '>';
		}

		return $headers;
	}

	/**
	 * @return null
	 */
	private function getBcc() {
		$bcc = get_option( 'cp_donations_email_confirmation_to' );
		if ( $bcc === false ) {
			return null;
		}

		return $bcc;
	}

	/**
	 * @return null
	 */
	private function getFrom() {
		$from = get_option( 'cp_donations_email_confirmation_from' );

		if ( $from === false ) {
			return null;
		}

		return $from;
	}

	/**
	 * Override default smtp settings.
	 *
	 * @param \PHPMailer $phpmailer
	 */
	public function mailtrap( $phpmailer ) {
		$phpmailer->isSMTP();
		$phpmailer->Host     = 'mailtrap.io';
		$phpmailer->SMTPAuth = true;
		$phpmailer->Port     = 2525;
		$phpmailer->Username = '498373213a4379d71';
		$phpmailer->Password = '1f48a0a0af6228';
	}
}