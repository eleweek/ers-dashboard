<?php
/**
 * Plugin Name: Charity Press Donations
 * Description: Get your donation forms from design to development rapidly.
 * Version: 0.3.2
 * License: GPL-2.0+
 */

use CharityPressDonations\Plugin;

/** @var wpdb $wpdb */
global $wpdb;

require "vendor/autoload.php";

$plugin = new Plugin();

$plugin['path']    = realpath( plugin_dir_path( __FILE__ ) ) . DIRECTORY_SEPARATOR;
$plugin['url']     = plugin_dir_url( __FILE__ );
$plugin['version'] = '0.3.2'; // don't forget to update the comment block as well
$plugin['nonce']   = 'weakEntropyMonkey';

// DB details
$plugin['db_version']     = 9;
$plugin['db_option_name'] = 'CharityPressDonations_db_version';
$plugin['db_table_name']  = $wpdb->prefix . 'charitypress_donations';

//Activator
$plugin['activator'] = function ( $c ) {
	return new CharityPressDonations\Activator( __FILE__, $c['db_version'], $c['db_option_name'], $c['db_table_name'] );
};

$plugin['updater'] = function () {
	return new CharityPressDonations\Updater( __FILE__ );
};

//Donation Observer - listening for donations
$plugin['donation_observer'] = function ( $c ) {
	return new CharityPressDonations\Library\DonationObserver( $c['nonce'], $c['db_table_name'] );
};

//Form - verify and output form
$plugin['form'] = function ( $c ) {
	return new CharityPressDonations\Library\Form( $c['nonce'] );
};

$plugin['donations_query'] = function ( $c ) {
	return new CharityPressDonations\Library\DonationsQuery( $c['db_table_name'] );
};

//Extend the campaign plugin
$plugin['campaigns'] = function ( $c ) {
	return new \CharityPressDonations\Library\CampaignIntegration( $c['db_table_name'] );
};

// Helpers
$plugin['helpers'] = function () {
	return new \CharityPressDonations\Helpers();
};

//Donations Reports Page
$plugin['dashboardUrl'] = 'charitypress-donations-reports';
$plugin['report'] = function ( $c ) {
	return new CharityPressDonations\ReportsPage(  $c['url'], $c['path'], $c['donations_query'], $c['dashboardUrl'] );
};

// Gateway config admin page
$plugin['gateway_config_page'] = function ( $c ) {
	return new \CharityPressDonations\Admin\GatewayConfigPage( $c['dashboardUrl'], $c['path'] );
};

$plugin['email'] = function () {
	return new \CharityPressDonations\Library\Email();
};

$plugin['email_settings'] = function ( $c ) {
	return new \CharityPressDonations\Admin\EmailSettings( $c['path'] );
};

$plugin->run();