<?php namespace CharityPressDonations\Library;


class SuccessResponse extends DonationResponse {

	public function run() {

		// update transaction status to success
		$this->transaction->success( $this->response );

		if ( $this->ajax ) {
			wp_send_json( $this->response->getData() );
		}

		wp_redirect( $this->transaction->getSuccessUrl() );
		exit();
	}
}