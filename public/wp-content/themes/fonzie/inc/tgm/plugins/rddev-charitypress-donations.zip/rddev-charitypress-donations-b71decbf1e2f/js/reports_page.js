(function ($) {
    'use strict';

    // document ready
    $(function () {
        var $inputs = $("#from, #to");
        var $table = $("#donations-table");
        var $export = $('#export');

        $table.after('<p><strong>Total:</strong> <strong class="total"></strong></p>');

        $inputs.datepicker({
            dateFormat: 'dd/mm/yy'
        });

        $('.clear').on('click', function (e) {
            e.preventDefault();
            $inputs.each(function () {
                $.datepicker._clearDate(this);
            });
            $table.data('dynatable').process();
        });

        $('#search-status').change(function () {
            var value = $(this).val();
            if (value === "") {
                $table.data('dynatable').queries.remove("status");
            } else {
                $table.data('dynatable').queries.add("status", value);
            }
            $table.data('dynatable').process();
        });

        function beforeProcess(e, data) {
            // adds information to the data object sent to the ajaxurl via dynatable
            data['action'] = 'charitypress-get-donations';
        }

        function afterAjax(request, response) {
            $export.data('args', response.args);

            if (response.sum) {
                $('.total').text(response.sum);
            } else {
                $('.total').text("");
            }
        }

        $table.on('dynatable:beforeProcess', beforeProcess);
        $table.on('dynatable:ajax:success', afterAjax);

        $table.dynatable({
            table: {
                defaultColumnIdStyle: 'underscore'
            },
            features: {
                pushState: false,
                search: false
            },
            dataset: {
                ajax: true,
                records: [],
                ajaxUrl: ajaxurl,
                ajaxMethod: 'POST'
            },
            writers: {},
            inputs: {
                queries: $inputs
            }
        });


        /**
         * Export function
         * @param e
         */
        function submit_csv_export_request(e) {
            e.preventDefault();

            var self = jQuery(this),
                args = $export.data('args');

            jQuery.each(args, function (key, item) {
                var i = jQuery('<input>', {type: 'hidden', name: 'args[' + key + ']'}).val(item);
                self.parent().append(i);
            });
            self.parent().submit();
        }

        $export.on('click', submit_csv_export_request);
    });


})(jQuery);
