<?php
namespace CharityPressDonations\Library;


abstract class DonationResponse {
	/**
	 * FailureResponse constructor.
	 *
	 * @param \Omnipay\Common\Message\ResponseInterface $response
	 * @param Transaction $transaction
	 * @param $ajax
	 */
	function __construct( $response, $transaction, $ajax = false ) {
		$this->response    = $response;
		$this->transaction = $transaction;
		$this->ajax        = $ajax;
	}

	abstract public function run();
}