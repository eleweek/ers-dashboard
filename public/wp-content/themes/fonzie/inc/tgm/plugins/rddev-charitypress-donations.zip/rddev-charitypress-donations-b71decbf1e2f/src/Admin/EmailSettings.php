<?php namespace CharityPressDonations\Admin;

class EmailSettings {

	public function __construct( $path ) {
		$this->views = $path . 'views/';
	}

	public function init() {
		add_action( 'admin_init', [ $this, 'settingsInit' ] );
		add_action( 'admin_menu', [ $this, 'addSubMenuPage' ] );
	}

	/**
	 * Section and field settings.
	 */
	public function settingsInit() {
		add_settings_section(
			'cp_donations_email_confirmation_settings',
			'Confirmation Email Settings',
			[ $this, 'emailSettingsRender' ],
			'cp_donations_email_settings'
		);

		add_settings_field(
			'cp_donations_email_confirmation_from',
			'From',
			[ $this, 'emailSettingsFromRender' ],
			'cp_donations_email_settings',
			'cp_donations_email_confirmation_settings'
		);

		add_settings_field(
			'cp_donations_email_confirmation_subject',
			'Subject',
			[ $this, 'emailSettingsSubjectRender' ],
			'cp_donations_email_settings',
			'cp_donations_email_confirmation_settings'
		);

		add_settings_field(
			'cp_donations_email_confirmation_to',
			'Blind copy to',
			[ $this, 'emailSettingsToRender' ],
			'cp_donations_email_settings',
			'cp_donations_email_confirmation_settings'
		);

		register_setting( 'cp_donations_email_confirmation_settings', 'cp_donations_email_confirmation_from' );
		register_setting( 'cp_donations_email_confirmation_settings', 'cp_donations_email_confirmation_subject' );
		register_setting( 'cp_donations_email_confirmation_settings', 'cp_donations_email_confirmation_to' );
	}

	/**
	 * Render section area
	 */
	public function emailSettingsRender() {
		echo '';
	}

	/**
	 * Render From input
	 */
	public function emailSettingsFromRender() {
		$from = get_option( 'cp_donations_email_confirmation_from' );

		echo sprintf(
			'<input type="text" id="cp_donations_email_confirmation_from" name="cp_donations_email_confirmation_from" value="%s"/>',
			$from !== false ? $from : ''
		);
	}

	/**
	 * Render Subject input
	 */
	public function emailSettingsSubjectRender() {
		$subject = get_option( 'cp_donations_email_confirmation_subject' );

		echo sprintf(
			'<input type="text" id="cp_donations_email_confirmation_subject" name="cp_donations_email_confirmation_subject" value="%s"/>',
			$subject !== false ? $subject : ''
		);
	}

	/**
	 * Render To input
	 */
	public function emailSettingsToRender() {
		$to = get_option( 'cp_donations_email_confirmation_to' );

		echo sprintf(
			'<input type="text" id="cp_donations_email_confirmation_to" name="cp_donations_email_confirmation_to" value="%s"/>
			<p><small>This email we also receive a copy of the email as a blind recipient. </small></p>',
			$to !== false ? $to : ''
		);
	}

	/**
	 * Add Email Settings sub page to Donation Reports page
	 */
	public function addSubMenuPage() {
		add_submenu_page(
			'charitypress-donations-reports',
			'Email Settings',
			'Email Settings',
			'manage_options',
			'cp-donations-email-settings',
			[ $this, 'outputPage' ]
		);
	}

	/**
	 * Render page for sub menu page
	 */
	public function outputPage() {
		include_once $this->views . 'email-settings-view.php';
	}
}