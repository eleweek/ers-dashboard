<?php

class TestForm extends WP_UnitTestCase {

	/** @var  CharityPressDonations\Library\Form */
	protected $form;

	public function setUp() {
		parent::setUp();

		$this->form = new CharityPressDonations\Library\Form( 'nonceString' );

		if ( ! file_exists( get_template_directory() . '/charitypress_donations' ) ) {
			mkdir( get_template_directory() . '/charitypress_donations', 0777, true );
		}

	}

	function testFormOpen() {
		$url   = site_url( 'wp-admin/admin-post.php' );
		$nonce = wp_create_nonce( 'nonceString' );

		$output = "<form action='{$url}' method='post' id=\"charitypress_donation_form\" class=\"monkey\" ><input type='hidden' name='action' value='charitypress_donate'/><input type='hidden' name='gateway' value='Stripe'/><input type='hidden' name='security' value='{$nonce}'/>";

		$this->expectOutputString( $output );
		$this->form->open( 'Stripe', [ 'class' => 'monkey' ] );
	}

	function testFormClose() {
		$output = "</form>";

		$this->expectOutputString( $output );
		$this->form->close();
	}

	function testOutputGivesErrorWhenTemplateNonExistent() {
		copy(
			__DIR__ . '/charitypress_donations/stripe-gateways.php',
			get_template_directory() . '/charitypress_donations/gateways.php'
		);

		$path_to_template = get_template_directory() . '/charitypress_donations/non-existent.php';

		$this->expectOutputString( "Can't find template '$path_to_template'." );
		$this->form->output( 'Stripe', 'non-existent', [ ] );
	}

	public function tearDown() {
		parent::tearDown();

		if ( file_exists( get_template_directory() . '/charitypress_donations/gateways.php' ) ) {
			unlink( get_template_directory() . '/charitypress_donations/gateways.php' );
		}
	}
}

