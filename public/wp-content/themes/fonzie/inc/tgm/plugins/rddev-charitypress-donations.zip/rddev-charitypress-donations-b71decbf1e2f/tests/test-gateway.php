<?php

class TestGateway extends WP_UnitTestCase {

	public function setUp() {
		parent::setUp();

		if ( ! file_exists( get_template_directory() . '/charitypress_donations' ) ) {
			mkdir( get_template_directory() . '/charitypress_donations', 0777, true );
		}

	}

	public function tearDown() {
		parent::tearDown();

		if ( file_exists( get_template_directory() . '/charitypress_donations/gateways.php' ) ) {
			unlink( get_template_directory() . '/charitypress_donations/gateways.php' );
		}
	}

	/**
	 * @expectedException Exception
	 * @expectedExceptionMessage Can't find gateways.php.
	 */
	function testGetConfigThrowsExceptionWhenNoGateways() {

		if ( file_exists( get_template_directory() . '/charitypress_donations/gateways.php' ) ) {
			unlink( get_template_directory() . '/charitypress_donations/gateways.php' );
		}

		\CharityPressDonations\Library\Gateway::getConfig();
	}

	function testGetConfigReturnsArray() {
		copy(
			__DIR__ . '/charitypress_donations/empty-gateways.php',
			get_template_directory() . '/charitypress_donations/gateways.php'
		);

		$this->assertTrue( is_array( \CharityPressDonations\Library\Gateway::getConfig() ) );
	}

	/**
	 * @expectedException Exception
	 * @expectedExceptionMessage Class '\Omnipay\FakePay\Gateway' not found
	 */
	function testVerifyThrowsExceptionWhenGatewayNotSupported() {
		copy(
			__DIR__ . '/charitypress_donations/fakepay-gateways.php',
			get_template_directory() . '/charitypress_donations/gateways.php'
		);

		\CharityPressDonations\Library\Gateway::verify( 'FakePay' );
	}

	/**
	 * @expectedException Exception
	 * @expectedExceptionMessage Gateway Stripe not present in config.
	 */
	function testVerifyThrowsExceptionWhenConfigForGatewayNonExistent() {
		copy(
			__DIR__ . '/charitypress_donations/empty-gateways.php',
			get_template_directory() . '/charitypress_donations/gateways.php'
		);

		\CharityPressDonations\Library\Gateway::verify( 'Stripe' );
	}

	/**
	 * @expectedException Exception
	 * @expectedExceptionMessage Gateway GoCardless not configured properly.
	 */
	function testVerifyThrowsExceptionWhenConfigNotCompleteForGateway() {
		copy(
			__DIR__ . '/charitypress_donations/partial-config-gateways.php',
			get_template_directory() . '/charitypress_donations/gateways.php'
		);

		\CharityPressDonations\Library\Gateway::verify( 'GoCardless' );
	}

	function testVerifyReturnsTrueWhenAllIsWell() {
		copy(
			__DIR__ . '/charitypress_donations/stripe-gateways.php',
			get_template_directory() . '/charitypress_donations/gateways.php'
		);

		$this->assertTrue( \CharityPressDonations\Library\Gateway::verify( 'Stripe' ) );
	}

	function testVerifyReturnsTrueWhenGatewayIsNotOfficial() {
		copy(
			__DIR__ . '/charitypress_donations/gocardlesssubscriptions-gateways.php',
			get_template_directory() . '/charitypress_donations/gateways.php'
		);

		$this->assertTrue( \CharityPressDonations\Library\Gateway::verify( 'GoCardlessSubscription' ) );
	}

	function testMakeReturnsGateway() {

		copy(
			__DIR__ . '/charitypress_donations/stripe-gateways.php',
			get_template_directory() . '/charitypress_donations/gateways.php'
		);

		$this->assertInstanceOf(
			'\Omnipay\Common\AbstractGateway',
			\CharityPressDonations\Library\Gateway::make( 'Stripe' )
		);
	}
}