<?php namespace CharityPressDonations\Library;

/**
 * Class Form
 *
 * Handles verifying form, gateway requirements and printing.
 *
 * @package CharityPressDonations\Library
 */
class Form {
	/** @var  string String to use when nonce generated */
	protected $nonce_string;

	function __construct( $nonce_string ) {
		$this->nonce_string = $nonce_string;
	}

	public function init() {
		add_action( 'charitypress_donation_form', [ $this, 'output' ], 10, 3 );
	}

	/**
	 * Defaults for form attributes.
	 *
	 * @var array
	 */
	protected static $defaults = [
		'id' => 'charitypress_donation_form',
	];

	/**
	 * Prints out the complete form.
	 *
	 * Verifies the template and the gateway.
	 *
	 * @param string $gateway Requested gateway
	 * @param string $template Absolute path to the template
	 * @param array $attributes Extra attributes to add to the form element
	 */
	public function output( $gateway, $template, array $attributes ) {
		$path_to_template = locate_template( 'charitypress_donations/' . $template . '.php' );

		try {
			// Check that the gateway requested is correctly configured
			Gateway::verify( $gateway );

			// Check template to be used exists
			$this->checkTemplate( $path_to_template );

		} catch ( \Exception $e ) {
			echo $e->getMessage();

			return;
		}

		$this->open( $gateway, $attributes );

		// get the passed in template
		load_template( $path_to_template );

		$this->close();

	}

	/**
	 * Outputs the beginning of the donation form.
	 *
	 * Merges in passed attributes with defaults.
	 *
	 * @param string $gateway Name of Gateway to use
	 * @param array $attributes Array of attributes to add to the form element
	 */
	public function open( $gateway, $attributes ) {
		$nonce = wp_create_nonce( $this->nonce_string );

		// direct form to admin post so we can listen for the admin_post_{action} hook
		$url = site_url( 'wp-admin/admin-post.php' );

		$attributes = array_merge( self::$defaults, $attributes );

		$extra_attributes = "";
		foreach ( $attributes as $attribute => $value ) {
			$extra_attributes .= sprintf( '%s="%s" ', $attribute, $value );
		}
		echo "<form action='{$url}' method='post' {$extra_attributes}>";
		echo "<input type='hidden' name='action' value='charitypress_donate'/>";
		echo "<input type='hidden' name='gateway' value='{$gateway}'/>";
		echo "<input type='hidden' name='security' value='{$nonce}'/>";
	}

	/**
	 * Outputs the end of the donation form.
	 */
	public function close() {
		echo "</form>";
	}

	/**
	 * Checks that the template provided exists.
	 *
	 * @param string $path_to_template Server path to template file
	 *
	 * @throws \Exception
	 */
	private function checkTemplate( $path_to_template ) {
		// check template exists
		if ( ! file_exists( $path_to_template ) ) {
			throw new \Exception( "Can't find template '$path_to_template'." );
		}
	}

}