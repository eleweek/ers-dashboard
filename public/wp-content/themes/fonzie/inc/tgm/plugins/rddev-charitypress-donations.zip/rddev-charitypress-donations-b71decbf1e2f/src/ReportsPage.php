<?php namespace CharityPressDonations;


use CharityPressDonations\Library\RecordProcessor;
use CharityPressDonations\Library\Transaction;
use League\Csv\Writer;

class ReportsPage {

	public function __construct( $url, $path, Library\DonationsQuery $donationsQuery, $dashboardUrl ) {
		$this->path  = $path;
		$this->views = $path . 'views' . DIRECTORY_SEPARATOR;
		$this->js    = $url . 'js' . DIRECTORY_SEPARATOR;
		$this->css   = $url . 'css' . DIRECTORY_SEPARATOR;

		$this->donationsQuery = $donationsQuery;
		$this->dashboardUrl   = $dashboardUrl;
	}

	public function init() {
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue' ] );
		add_action( 'admin_menu', [ $this, 'addMenuPages' ] );

		add_action( 'wp_ajax_charitypress-get-donations', [ $this, 'queryDonations' ] );
		add_action( 'admin_post_charitypress-donations-generate-csv', [ $this, 'generateCSV' ] );
	}

	public function enqueue() {
		wp_enqueue_style( 'jquery-ui-datepicker-style', $this->css . 'datepicker-ui.css' );
		wp_enqueue_style( 'charity-press-donations', $this->css . 'reports_page.css' );

		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_enqueue_script( 'dynatable', $this->js . 'jquery.dynatable.js', [ 'jquery' ], false, true );
		wp_enqueue_script( 'charity-press-donations', $this->js . 'reports_page.js', [
			'jquery',
			'dynatable',
		], false, true );
	}

	public function addMenuPages() {
		add_menu_page(
			'Donations',
			'Donations',
			'manage_options',
			$this->dashboardUrl,
			[ $this, 'outputMenuPage' ],
			'dashicons-clipboard',
			11.11
		);
	}

	public function outputMenuPage() {
		include $this->views . 'donations_report_page.php';
	}

	public function queryDonations() {

		$this->donationsQuery
			->setTimeRange( $this->getTimerange() )
			->setPage( filter_input( INPUT_POST, 'page' ) )
			->setPerPage( filter_input( INPUT_POST, 'perPage' ) )
			->setOffset( filter_input( INPUT_POST, 'offset' ) )
			->setOrderby( $this->getOrderBy() );

		unset( $_POST['queries']['to'], $_POST['queries']['from'] );

		if ( ! empty( $_POST['queries'] ) ) {
			foreach ( $_POST['queries'] as $column => $value ) {
				$this->donationsQuery->addWhere( $column, "= '$value'" );
			}
		}

		$response = $this->donationsQuery->run();

		$response['records'] = RecordProcessor::process(
			$response['records'],
			apply_filters( 'charitypress/donations/report_fields', $this->defaultReportFields() )
		);

		header( 'Content-Type: application/json' );
		echo json_encode( $response );
		die();
	}

	private function getOrderBy() {
		$sorts = filter_input( INPUT_POST, 'sorts', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );

		if ( ! $sorts ) {
			return null;
		}

		$orderby = '';
		foreach ( $sorts as $sort => $order ) {
			$order = ( '-1' == $order ) ? 'DESC' : 'ASC';
			$orderby .= "$sort $order, ";
		}

		return rtrim( $orderby, ', \t\n' );

	}

	private function getTimerange() {
		$queries = filter_input( INPUT_POST, 'queries', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );

		if ( empty( $queries['from'] ) && empty( $queries['to'] ) ) {
			return null;
		}

		$from = empty( $queries['from'] ) ? current_time( 'mysql' ) : \DateTime::createFromFormat( 'd/m/Y', $queries['from'] )->format( 'Y-m-d 00:00:00' );
		$to   = empty( $queries['to'] ) ? current_time( 'mysql' ) : \DateTime::createFromFormat( 'd/m/Y', $queries['to'] )->format( 'Y-m-d 23:59:59' );

		return [
			'from' => $from,
			'to'   => $to,
		];
	}

	public function generateCSV() {

		// Get args from post
		$args = filter_input( INPUT_POST, 'args', FILTER_DEFAULT, FILTER_REQUIRE_ARRAY );

		$timerange = ! empty( $args['from'] ) ? [ 'from' => $args['from'], 'to' => $args['to'] ] : null;

		$this->donationsQuery
			->setTimeRange( $timerange )
			->setPage( 1 )
			->setPerPage( 9223372036854775807 )
			->setOffset( 0 )
			->setOrderby( $args['orderby'] );

		$response = $this->donationsQuery->run();

		$requiredFields = apply_filters( 'charitypress/donations/export_fields', $this->csvFieldsRequired() );

		$records = $this->getRequiredFields( $requiredFields, $response['records'] );

		// Create the CSV in memory
		$csv = Writer::createFromFileObject( new \SplTempFileObject() );

		// Insert CSV header
		$csv->insertOne( array_keys( $requiredFields ) );

		// Insert data
		$csv->insertAll( $records );

		// Push to Download
		$csv->output( apply_filters( 'charitypress/donations/export_filename', 'charitypress_donations_export' ) . '.csv' );
	}

	public function csvFieldsRequired() {
		return [
			'ID'             => 'id',
			'Amount'         => 'amount',
			'Status'         => 'status',
			'Created'        => 'created',
			'Gateway'        => 'gateway',
			'Transaction ID' => 'gateway_transaction_id',
			'Recurring'      => 'recurring',
		];
	}

	public function defaultReportFields() {

		return [
			'amount'                 => 'amount',
			'status'                 => 'status',
			'created'                => function ( Transaction $record ) {
				return \DateTime::createFromFormat( 'Y-m-d H:i:s', $record->getCreated() )->format( 'd/m/Y' );
			},
			'donor'                  => function ( Transaction $record ) {
				/** @var Transaction $record */
				$donor = $record->getDonor();

				$donor['firstName'] .= " " . $donor['lastName'];
				unset( $donor['lastName'] );

				$donor = array_filter( $donor );

				return implode( ', ', $donor );
			},
			'gateway'                => 'gateway',
			'gateway_transaction_id' => 'gateway_transaction_id',
			'gift_aid'               => 'gift_aid',
		];
	}

	public function getRequiredFields( $csvFieldsRequired, $records ) {

		$newRecords = [ ];

		/** @var \CharityPressDonations\Library\Transaction $record */
		foreach ( $records as $index => $record ) {
			foreach ( $csvFieldsRequired as $key => $requiredField ) {
				$pieces = explode( '.', $requiredField );
				$temp   = $record->toArray();
				foreach ( $pieces as $piece ) {
					$temp = &$temp[ $piece ];
				}
				$newRecords[ $index ][ $key ] = $temp;
			}
		}

		return $newRecords;
	}


}
