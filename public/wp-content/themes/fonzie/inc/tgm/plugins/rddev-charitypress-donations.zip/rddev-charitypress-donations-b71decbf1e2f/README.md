# README #

CharityPress Donations Plugin

Aimed at getting designs to working form as quick as possible.

## Setup ##
1. Install and activate Plugin
2. Create a directory in your theme named `charitypress_donations`
3. Add a form template to that directory (see form templates below)
4. Fill in the details on the Gateway Setup settings page (wp-admin/admin.php?page=cp-gateway-settings)
5. Add an action hook to whichever template you like in your theme (see action hook below)

## Gateway Config ##

For each gateway that you intend to use you will need to provide that gateway's required setup fields in the Gateway Setup page.
    
## Form Templates ##

CharityPress Donations uses forms provided by you. These forms need to be in your `charitypress_donations` directory 
within your theme.

CharityPress Donations provides the opening and closing of your form so you need only provide the fields.

    <input type="hidden" name="success_url" value="<?php echo get_permalink(4); ?>"/>
    <div class="row">
        <p class="form-group col-md-5">
            <label for="card[number]">Number</label>
            <input type="text" name="card[number]" value="4242424242424242"/>
        </p>
    
        <p class="form-group col-md-2">
            <label for="card[expiryMonth]">Expiry Month</label>
            <input type="number" name="card[expiryMonth]" value="05"/><br>
        </p>
        <p class="form-group col-md-2">
            <label for="card[expiryYear]">Expiry Year</label>
            <input type="number" name="card[expiryYear]" value="2016"/>
        </p>
        <p class="form-group col-md-2">
            <label for="card[cvv]">Security Code</label>
            <input type="number" name="card[cvv]" value="100"/>
        </p>
    </div>
    <div class="row">
        <p class="form-group col-md-6">
            <label for="amount">Amount</label>
            <input type="number" min="0" step="0.01" name="amount" value="10.00"/>
        </p>
    </div>
    <div class="row">
        <p class="form-group col-md-3">
            <button type="submit" class="btn btn-primary">Submit</button>
        </p>
    </div>
    
The bare minimum that you need to provide is `card[number]` `card[expiryMonth]` `card[expiryYear]` `card[cvv]` 
and `amount`. To store arbitrary data see custom fields below.

### Hidden Fields ###

You can also provide some hidden fields to help with certain gateways. For example off-site gateways normally require 
a url to redirect the donor to upon successful completion.

- success_url
- cancel_url

## In-page Action Hook ##

To finally output the form include the following in your theme:

    <?php do_action('charitypress_donation_form',
        'GatewayName',
        'donation-form-template-name',
        ['extra' => 'attributes', 'tobepassed' => 'totheformtag', 'class' => 'upper', 'id' => 'donation_form']);
    ?>
    
## Customise the Export

To customise the Export filename and fields use the following filters:

    <?php
    
    function charitypress_change_export_columns(){
        // example columns
    	return [
    		'ID' => 'id',
    		'Amount' => 'amount',
    		'Status' => 'status',
    		'Created' => 'created',
    		'Gateway' => 'gateway',
    		'Transaction ID' => 'gateway_transaction_id',
    		'Donor Email' => 'donor.email', // use dot notation to access sub arrays
    		'Donor Title' => 'donor.title',
    		'Donor First Name' => 'donor.firstName',
    		'Donor Last Name' => 'donor.lastName',
    		'Gift Aid' => 'gift_aid',
    		'Reason for giving' => 'extras.givingReason',
    		'How did you hear about us?' => 'extras.referralName',
    	];
    }
    add_filter('charitypress/donations/export_fields', 'charitypress_change_export_columns');
    
    add_filter('charitypress/donations/export_filename', function(){
        // choose a file friendly name (no spaces)
    	return 'my_charity_donations_export';
    });

## Customise the Reports Page

To show custom columns and output on the reports page you must use two filters. First you must customise what is returned
for each transaction returned from the database. Then you must alter the columns that are shown in the table.

### Customise returned fields

    function customise_donations_reports_output( $defaults ) {

        // just name a property of the transaction and it will be added
        $defaults['updated'] = 'updated';

        // or use a function that gets passed the whole transaction
        // look in the \CharityPressDonations\Library\Transaction class to see what methods are available
        $defaults['leaf_name'] = function ( $record ) {
            $extras = $record->getExtras();

            if ( ! empty( $extras['leaf'] ) && ! empty( $extras['leaf']['inscription'] ) ) {
                return $extras['leaf']['inscription'];
            }

            return '';
        };

        return $defaults;
    }

    add_filter( 'charitypress/donations/report_fields', 'customise_donations_reports_output' );

The defaults passed to the hook look something like this:

    [
        'amount'                 => 'amount',
        'status'                 => 'status',
        'created'                => function ( Transaction $record ) {
            return \DateTime::createFromFormat( 'Y-m-d H:i:s', $record->getCreated() )->format( 'd/m/Y' );
        },
        'donor'                  => function ( Transaction $record ) {
            /** @var Transaction $record */
            $donor = $record->getDonor();

            $donor['firstName'] .= " " . $donor['lastName'];
            unset( $donor['lastName'] );

            $donor = array_filter( $donor );

            return implode( ', ', $donor );
        },
        'gateway'                => 'gateway',
        'gateway_transaction_id' => 'gateway_transaction_id',
        'gift_aid'               => 'gift_aid',
    ]

and result in json output like this:

    {
        amount: "5.00",
        created: "18/04/2016",
        donor: "Merritt Bird, Address 1, Town, M11DW, Manchester, GB, xuhywy@gmail.com",
        gateway: "WorldPay",
        gateway_transaction_id: null,
        gift_aid: true,
        status: "pending"
    }

### Customise report columns

    function customise_donations_reports_columns( $defaults ) {
    	$defaults[] = [
    		'title'    => 'Leaf Name',
    		'sortable' => false
    	];

    	return $defaults;
    }
    add_filter( 'charitypress/donations/report_columns', 'customise_donations_reports_columns' );

The defaults passed to this hook are these:

    [
    	[ 'title' => 'Amount' ],
    	[ 'title' => 'Status' ],
    	[ 'title' => 'Created' ],
    	[ 'title' => 'Donor', 'sortable' => false ],
    	[ 'title' => 'Gateway' ],
    	[ 'title' => 'Gateway Transaction ID' ],
    	[ 'title' => 'Gift Aid' ],
    ]

`sortable` refers to wether you can run a `SORT BY` query against this column name. Generally if you are using a function in the corresponding field customisation then you should set this to false. Basically `SORT BY 'Donor'` in this instance will throw an error in SQL because that column doesn't exist in the database; so we set it to `false`.

Also note that in the example above in order to provide a column for the `leaf_name` key that we added to the fields exported we had to create an entry with the `title` set to __Leaf Name__. The reports page lowercases and replaces spaces with underscores for the column title in order to know what to look for in the returned json.

## Custom Fields

To save arbitrary data against a transaction use the extras array. 

In your donation form just set the name of an input to save to extras.

    <input type="text" name="extras[favouriteCheese]" value="Brie">
    
Now in your export you can include this:

    function charitypress_change_export_columns(){
            return [
        		'Amount' => 'amount',
        		'Favourite Cheese' => 'extras.favouriteCheese'
        	];
        }
    add_filter('charitypress/donations/export_fields', 'charitypress_change_export_columns');

And you can show them in your reports page like this:

    function customise_donations_reports_output( $defaults ) {
        $defaults['leaf_name'] = function ( $record ) {
            $extras = $record->getExtras();

            if ( ! empty( $extras['favouriteCheese'] ) ) {
                return $extras['leaf']['favouriteCheese'];
            }

            return '';
        };
        return $defaults;
    }

    add_filter( 'charitypress/donations/report_fields', 'customise_donations_reports_output' );

    function customise_donations_reports_columns( $defaults ) {
        $defaults[] = [
            'title'    => 'Favourite Cheese',
            'sortable' => false
        ];
        return $defaults;
    }
    add_filter( 'charitypress/donations/report_columns', 'customise_donations_reports_columns' );