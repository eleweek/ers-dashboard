<?php namespace CharityPressDonations\Library;

class CampaignIntegration {

	public function __construct( $db_table ) {
		$this->db_table = $db_table;
	}

	public function init() {
		add_filter( 'acf/load_field/name=action_type', [ $this, 'addCampaignActionTypes' ] );

		add_filter( 'charitypress/donations/campaign_total', [ $this, 'getCampaignTotal' ], 10, 2 );
	}

	public function addCampaignActionTypes( $field ) {

		$field['choices']['donate'] = "Donate";

		return $field;
	}

	public function getCampaignTotal( $total, $campaign ) {
		global $wpdb;

		$total += $wpdb->get_var( "SELECT sum(amount) FROM {$this->db_table} WHERE campaign = $campaign AND status = 'success'" );

		return $total;
	}
}