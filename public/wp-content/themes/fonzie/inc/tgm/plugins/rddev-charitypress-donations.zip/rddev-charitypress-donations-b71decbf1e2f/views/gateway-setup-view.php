<div class="wrap">
	<h2><?php echo get_admin_page_title(); ?></h2>

<p>This is where you set up the use of your gateways.</p>

<form method="post" action="options.php">
	<?php
	settings_fields( 'cp_gateway_setup' );
	do_settings_sections( 'cp_page_cp_gateway_setup' );
	submit_button( 'Save' );
	?>
</form>

</div>

<script class="template" type="text/template">
	<tr>
		<th scope="row"><label for="<%= index %>"><%= index %></label></th>
		<td>
			<% if (type == 'checkbox') { %>
			<input type="hidden" name="<%= frequency %>_gateway[parameters][<%= index %>]" id="<%= index %>" value="false" />
			<% } %>
			<% if(type == 'select') { %>
			<select name="<%= frequency %>_gateway[parameters][<%= index %>]"
			        type="<%= type %>"
			        id="<%= index %>"
			>
				<% for (var i = 0; i < value.length; i++) { %>
				<option value="<%= value[i] %>"><%= value[i] %></option>
				<% } %>
			</select>
			<% } else { %>
			<input name="<%= frequency %>_gateway[parameters][<%= index %>]" type="<%= type %>"
			       id="<%= index %>" value="<%= value %>"
			       class="<% if (type == 'text') { %>regular-text<%}%>"
			/>
			<% } %>
		</td>
	</tr>
</script>
<script>
	(function ($) {
		$('.gateway_selector').on('ready, change', function () {
			var gateway_name = $(this).val();
			var frequency = $(this).data('frequency');
			var $el = $('.' + frequency + '_parameters');
			var template = _.template(jQuery('script.template').html());

			function appendParameters(resp) {
				$el.html("");
				$.each(resp, function (index, value) {
					var type;
					switch (typeof(value)) {
						case 'boolean':
							type = 'checkbox';
							value = true;
							break;
						case 'object':
							type = 'select';
							break;
						default:
							type = 'text';
					}

					$el.append(template({index: index, value: value, type: type, frequency: frequency}));
				});
				$(document).trigger('parameter-check');
			}

			$.ajax({
				type: 'POST',
				url: ajaxurl,
				data: {
					action: 'cp_get_gateway_parameters',
					gateway_name: gateway_name
				},
				success: appendParameters
			});

		});

		/**
		 * Check whether we have any inputs or not and disable submit if we don't
		 */
		$(document).on('parameter-check', function () {
			if ($('.form-table input').length > 0) {
				$('#submit').attr('disabled', false);
			} else {
				$('#submit').attr('disabled', true);
			}
		})

	})(jQuery)
</script>