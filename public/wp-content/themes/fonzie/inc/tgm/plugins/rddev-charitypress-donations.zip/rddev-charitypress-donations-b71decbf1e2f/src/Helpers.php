<?php namespace CharityPressDonations;

class Helpers {

	public static function getSingleGateways() {
		$json     = json_decode( file_get_contents( dirname( __DIR__ ) . "/composer.json" ), true );
		$packages = $json['extra']['gateways'];

		$gateways = [ ];

		foreach ( $packages as $gateway ) {
			$class = \Omnipay\Common\Helper::getGatewayClassName( $gateway['name'] );
			if ( class_exists( $class ) && ! $gateway['recurring'] ) {
				$gateways[] = $class;
			}
		}

		return $gateways;
	}

	public static function getRecurringGateways() {
		$json     = json_decode( file_get_contents( dirname( __DIR__ ) . "/composer.json" ), true );
		$packages = $json['extra']['gateways'];

		$gateways = [ ];

		foreach ( $packages as $gateway ) {
			$class = \Omnipay\Common\Helper::getGatewayClassName( $gateway['name'] );
			if ( class_exists( $class ) && $gateway['recurring'] ) {
				$gateways[] = $class;
			}
		}

		return $gateways;
	}
}