<?php namespace CharityPressDonations\Library;

use Valitron\Validator as V;

class Validator {

	protected $rules = [
		'required'  => [
			[ 'title' ],
			[ 'firstName' ],
			[ 'lastName' ],
			[ 'email' ],
			//[ 'number' ],
			//[ 'expiryMonth' ],
			//[ 'expiryYear' ],
			//[ 'cvv' ],
			[ 'amount' ]
		],
		'numeric'   => [
			[ 'number' ],
			[ 'amount' ],
			[ 'expiryMonth' ],
			[ 'expiryYear' ],
			[ 'cvv' ]
		],
		'lengthMax' => [
			[ 'number', 19 ],
		],
		'email'     => [
			[ 'email' ]
		],
	];

	protected $labels = [
		'title'           => 'Title',
		'firstName'       => 'First name',
		'lastName'        => 'Last name',
		'email'           => 'Email address',
		'expiryMonth'     => 'Expiration Month',
		'expiryYear'      => 'Expiration Year',
		'billingAddress1' => 'Address 1',
		'billingCity'     => 'Town',
		'billingState'    => 'County',
		'billingPostcode' => 'Postcode',
		'billingCountry'  => 'Country',
	];

	/** @var V Valitron\Validator */
	protected $v;

	protected $valid = false;

	protected $errors;

	public function __construct( $postValues ) {

		$v = new V( $postValues );
		$v->rules( $this->rules );
		$v->labels( $this->labels );

		$this->valid  = $v->validate();
		$this->errors = $v->errors();

	}

	public function valid() {
		return $this->valid;
	}

	public function errors() {
		return $this->errors;
	}

}