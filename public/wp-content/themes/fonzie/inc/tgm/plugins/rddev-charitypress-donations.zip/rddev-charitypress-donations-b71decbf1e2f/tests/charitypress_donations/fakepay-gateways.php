<?php

return [
	'FakePay' => [
		'apiKey' => 'sk_test_randomcharacters'
	],
];