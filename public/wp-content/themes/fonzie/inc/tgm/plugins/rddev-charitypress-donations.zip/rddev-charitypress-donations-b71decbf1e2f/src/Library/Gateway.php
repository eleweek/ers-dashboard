<?php namespace CharityPressDonations\Library;


use Omnipay\Omnipay;

class Gateway {

	/**
	 * Find and load the config file that should exist in the plugin user's current theme.
	 *
	 * @return mixed
	 * @throws \Exception
	 */
	static function getConfig() {
		$single = get_option('single_gateway', []);
		$recurring = get_option('recurring_gateway', []);

		$gateways = [];

		if (!empty($single['shortname'])) {
			$gateways[$single['shortname']] = $single['parameters'];

		}

		if (!empty($recurring['shortname'])) {
			$gateways[$recurring['shortname']] = $recurring['parameters'];
		}

		return $gateways;
	}

	/**
	 * Check and then create the requested gateway object.
	 *
	 * @param string $gateway_name The requested gateway
	 *
	 * @return \Omnipay\Common\AbstractGateway
	 * @throws \Exception
	 *
	 */
	static function make( $gateway_name ) {

		self::verify( $gateway_name );

		$configured_gateways = self::getConfig();

		$gateway_config  = $configured_gateways[ $gateway_name ];
		$omnipay_gateway = Omnipay::create( $gateway_name );

		foreach ( $gateway_config as $key => $value ) {
			$setter = 'set' . ucwords( $key );
			$omnipay_gateway->$setter( $value );
		}

		return $omnipay_gateway;
	}

	/**
	 * Checks that the requested gateway exists and is configured correctly.
	 *
	 * @param string $gateway_name The requested gateway
	 *
	 * @return bool
	 * @throws \Exception
	 */
	public static function verify( $gateway_name ) {

		$configured_gateways = self::getConfig();

		// Check config exists for gateway
		if ( empty( $configured_gateways[ $gateway_name ] ) ) {
			throw new \Exception( "Gateway {$gateway_name} not present in config." );
		}

		// Create gateway for given gateway shortname
		// throws exception if Gateway doesn't exist
		$parameters_required = Omnipay::create( $gateway_name )->getDefaultParameters();

		// Check all required gateway parameters are set
		$intersect = array_intersect_key( $configured_gateways[ $gateway_name ], $parameters_required );
		if ( count( $intersect ) != count( $parameters_required ) ) {
			throw new \Exception( "Gateway {$gateway_name} not configured properly." );
		}

		return true;

	}
}