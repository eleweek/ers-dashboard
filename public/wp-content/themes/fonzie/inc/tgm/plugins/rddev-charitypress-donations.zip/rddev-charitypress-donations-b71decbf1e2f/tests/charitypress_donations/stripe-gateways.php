<?php

return [
	'Stripe' => [
		'apiKey' => 'sk_test_randomcharacters'
	],
];