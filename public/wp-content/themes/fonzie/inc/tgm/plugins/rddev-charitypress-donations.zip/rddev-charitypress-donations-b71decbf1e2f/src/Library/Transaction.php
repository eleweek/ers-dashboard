<?php namespace CharityPressDonations\Library;

use JsonSerializable;
use Omnipay\Common\Message\ResponseInterface;

/**
 * Class Transaction
 *
 * For reading and creating Transactions in the database.
 *
 * @package CharityPressDonations\Library
 */
class Transaction implements JsonSerializable {

	/** @var  integer */
	protected $id;

	/** @var  string */
	protected $gateway;

	/** @var string */
	protected $status = 'pending';

	/** @var  string */
	protected $failure_message;

	/** @var  string */
	protected $amount;

	/** @var string */
	protected $currency = 'GBP';

	/** @var  array|null JSONified on save */
	protected $donor;

	/** @var  bool */
	protected $gift_aid = false;

	/** @var  string */
	protected $success_url;

	/** @var  string */
	protected $cancel_url;

	/** @var array|null JSONified on save */
	protected $recurring = null;

	/** @var  string */
	protected $gateway_transaction_id;

	/** @var  array JSONified on save */
	protected $extras;

	/** @var  integer Campaign ID */
	protected $campaign;

	/** @var  \Datetime */
	protected $created;

	/** @var  \Datetime */
	protected $updated;

	/** @var  string */
	protected $table_name;

	function __construct( array $args = null, $db_table_name = null ) {
		$this->table_name = $db_table_name;

		foreach ( $args as $key => $value ) {

			// If setter exists use that, converting snake case to camelcase
			$method = 'set' . preg_replace_callback( '/(?:^|_)(.?)/', function ( $matches ) {
					return strtoupper( $matches[1] );
				}, $key );
			if ( method_exists( $this, $method ) ) {
				$this->$method( $value );
				continue;
			}

			if ( property_exists( __CLASS__, $key ) ) {
				$this->$key = $value;
			}
		}

		if ( ! empty( $args['card'] ) ) {
			$this->createDonor( $args['card'] );
		}
	}

	/**
	 * @return integer
	 */
	public function getID() {
		return $this->id;
	}

	/**
	 * @return mixed
	 */
	public function getAmount() {
		return $this->amount;
	}

	/**
	 * @param $amount
	 *
	 * @return Transaction
	 */
	public function setAmount( $amount ) {
		$this->amount = number_format( $amount, 2, '.', '' );

		return $this;
	}

	/**
	 * @return string
	 */
	public function getCurrency() {
		return $this->currency;
	}

	/**
	 * @return array
	 */
	public function getDonor() {
		return $this->donor;
	}

	/**
	 * @param array|string $donor
	 *
	 * @return Transaction
	 */
	public function setDonor( $donor ) {
		if ( ! is_array( $donor ) ) {
			$donor = json_decode( stripslashes( $donor ), true );
		}

		$this->donor = $donor;

		return $this;
	}

	/**
	 * @return boolean
	 */
	public function getGiftAid() {
		return $this->gift_aid;
	}

	/**
	 * @param boolean $gift_aid
	 *
	 * @return Transaction
	 */
	public function setGiftAid( $gift_aid ) {
		$this->gift_aid = (bool) $gift_aid;

		return $this;
	}

	/**
	 * @return string
	 */
	public function getStatus() {
		return $this->status;
	}

	/**
	 * @param string $status
	 */
	public function setStatus( $status ) {
		$this->status = $status;
	}

	/**
	 * @return string
	 */
	public function getSuccessUrl() {
		return $this->success_url;
	}

	/**
	 * @return string
	 */
	public function getCancelUrl() {
		return $this->cancel_url;
	}

	/**
	 * @return string
	 */
	public function getRecurring() {
		return $this->recurring;
	}

	/**
	 * @param array|string $recurring
	 *
	 * @return Transaction
	 */
	public function setRecurring( $recurring ) {
		if ( ! is_array( $recurring ) ) {
			$recurring = json_decode( stripslashes( $recurring ), true );
		}

		$this->recurring = $recurring;

		return $this;
	}

	/**
	 * @return mixed
	 */
	public function getGateway() {
		return $this->gateway;
	}

	public function getCreated() {
		return $this->created;
	}

	/**
	 * @return array
	 */
	public function getExtras() {
		return $this->extras;
	}

	/**
	 * @param array|string $extras
	 */
	public function setExtras( $extras ) {
		if ( ! is_array( $extras ) ) {
			$extras = json_decode( stripslashes( $extras ), true );
		}

		$this->extras = $extras;
	}

	public function getCampaign() {
		return $this->campaign;
	}

	/**
	 * Whether or not the transaction has an Id or not.
	 *
	 * @return bool
	 */
	private function exists() {
		return ! is_null( $this->id );
	}

	/**
	 * Static method to quickly generate and save a transaction.
	 *
	 * @param $args
	 * @param $db_table_name
	 *
	 * @return Transaction
	 */
	public static function create( $args, $db_table_name ) {
		$transaction = new self( $args, $db_table_name );
		$transaction->save();

		return $transaction;

	}

	/**
	 * Find the transaction with the given id in the given table.
	 *
	 * @param $id
	 * @param $db_table_name
	 *
	 * @return Transaction
	 */
	public static function find( $id, $db_table_name ) {
		/** @var \wpdb $wpdb */
		global $wpdb;
		$result = $wpdb->get_row( "SELECT * FROM $db_table_name where id = $id", ARRAY_A );

		return new self( $result, $db_table_name );
	}

	/**
	 * Save the current settings to the db.
	 */
	public function save() {
		/** @var \wpdb $wpdb */
		global $wpdb;

		$data = [
			'gateway'                => $this->gateway,
			'amount'                 => $this->amount,
			'currency'               => $this->currency,
			'status'                 => $this->status,
			'donor'                  => ( $this->donor ) ? wp_unslash( json_encode( $this->donor ) ) : null,
			'gift_aid'               => $this->gift_aid,
			'failure_message'        => $this->failure_message,
			'success_url'            => $this->success_url,
			'cancel_url'             => $this->cancel_url,
			'gateway_transaction_id' => $this->gateway_transaction_id,
			'recurring'              => ( $this->recurring ) ? wp_unslash( json_encode( $this->recurring ) ) : null,
			'extras'                 => ( $this->extras ) ? wp_unslash( json_encode( $this->extras ) ) : null,
			'campaign'               => $this->campaign,
		];

		if ( $this->exists() ) {
			// do update
			$data['updated'] = current_time( 'mysql' );
			$wpdb->update( $this->table_name, $data, [ 'id' => $this->id ] );
			$this->updated = $data['updated'];
		} else {
			$data['created'] = current_time( 'mysql' );
			$wpdb->insert( $this->table_name, $data );
			$this->id      = $wpdb->insert_id;
			$this->created = $data['created'];
		}

	}

	/**
	 * Set the transaction status to success and save
	 *
	 * @param ResponseInterface $response
	 */
	public function success( ResponseInterface $response ) {
		$this->status                 = 'success';
		$this->gateway_transaction_id = $response->getTransactionReference();
		$this->save();
	}

	/**
	 * Set the transaction status to fail and save
	 *
	 * @param ResponseInterface $response
	 */
	public function fail( ResponseInterface $response ) {
		$this->status                 = 'fail';
		$this->gateway_transaction_id = $response->getTransactionReference();
		$this->failure_message        = $response->getMessage();
		$this->save();
	}

	/**
	 * Go through given array looking for parameters required for donor
	 *
	 * @param array $card
	 */
	private function createDonor( array $card ) {
		$paramsWanted = [
			'title',
			'firstName',
			'lastName',
			'billingAddress1',
			'billingAddress2',
			'billingCity',
			'billingPostcode',
			'billingState',
			'billingCountry',
			'billingPhone',
			'email'
		];

		$donor = [ ];

		foreach ( $paramsWanted as $value ) {
			$donor[ $value ] = ( ! empty( $card[ $value ] ) ) ? $card[ $value ] : '';
		}

		$this->setDonor( $donor );
	}

	public function toArray() {
		/** Todo: be more selective */
		return get_object_vars( $this );
	}

	/**
	 * Specify data which should be serialized to JSON
	 * @link http://php.net/manual/en/jsonserializable.jsonserialize.php
	 * @return mixed data which can be serialized by <b>json_encode</b>,
	 * which is a value of any type other than a resource.
	 * @since 5.4.0
	 */
	function jsonSerialize() {
		/** Todo: be more selective */
		$vars = get_object_vars( $this );
		unset( $vars['table_name'] );

		return $vars;
	}
}
