<?php namespace CharityPressDonations;


class Activator {

	/**
	 * @param string $main_file Location of main plugin file
	 * @param integer $db_version Current db version (update to trigger change)
	 * @param string $db_option_name Option name to use to store latest db version
	 */
	function __construct( $main_file, $db_version, $db_option_name, $db_table_name ) {
		$this->main_file      = $main_file;
		$this->db_version     = $db_version;
		$this->db_option_name = $db_option_name;
		$this->db_table_name  = $db_table_name;
	}

	public function init() {
		register_activation_hook( $this->main_file, [ $this, 'activate' ] );
		add_action( 'plugins_loaded', [ $this, 'dbVersionCheck' ] );
	}

	public function activate() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE $this->db_table_name (
                id MEDIUMINT(11) NOT NULL AUTO_INCREMENT,
                gateway VARCHAR(255) NOT NULL,
                amount NUMERIC(15,2) NOT NULL,
                currency VARCHAR(4),
                status VARCHAR(255),
                donor LONGTEXT,
                gift_aid TINYINT(1),
                failure_message TEXT,
                gateway_transaction_id TEXT,
                success_url VARCHAR(2083),
                cancel_url VARCHAR(2083),
                recurring LONGTEXT,
                extras LONGTEXT,
                campaign MEDIUMINT(11),
                created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
                updated datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
                PRIMARY KEY  (id)
            ) $charset_collate;";

		require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
		dbDelta( $sql );

		add_option( $this->db_option_name, $this->db_version );
	}

	public function dbVersionCheck() {
		// check saved option matches current version
		if ( get_option( $this->db_option_name ) != $this->db_version ) {
			$this->activate();
		}
	}
}