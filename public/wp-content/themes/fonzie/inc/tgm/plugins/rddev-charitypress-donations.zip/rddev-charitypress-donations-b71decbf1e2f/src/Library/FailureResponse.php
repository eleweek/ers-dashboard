<?php namespace CharityPressDonations\Library;

use CharityPressDonations\Log;

class FailureResponse extends DonationResponse {

	public function run() {

		// update transaction status to fail
		$this->transaction->fail( $this->response );

		Log::notice("Payment failed", [
			'response' => $this->response->getMessage(),
			'data' => $this->response->getData(),
			'file' => __FILE__
		]);

		if ( $this->ajax ) {
			wp_send_json( $this->response->getData() );
		}

		// add response to url
		$return_url = add_query_arg(
			['transaction' => $this->transaction->getID()],
			$this->transaction->getCancelUrl()
		);

		wp_redirect( $return_url );
		exit();
	}
}