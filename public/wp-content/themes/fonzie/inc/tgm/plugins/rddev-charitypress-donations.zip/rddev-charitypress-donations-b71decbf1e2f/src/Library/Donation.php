<?php namespace CharityPressDonations\Library;


use Omnipay\Common\CreditCard;
use Omnipay\Common\GatewayInterface;

class Donation {

	/**
	 * @param Transaction $transaction
	 * @param CreditCard $card
	 * @param GatewayInterface $gateway
	 * @param Boolean $ajax
	 *
	 * @return SuccessResponse
	 */
	public static function make( Transaction $transaction, CreditCard $card, GatewayInterface $gateway, $ajax ) {
		try {
			$args = [
				'amount'        => $transaction->getAmount(),
				'currency'      => $transaction->getCurrency(),
				'transactionId' => $transaction->getID(),
				'card'          => $card,
				'returnUrl'     => admin_url( "admin-post.php?action=charitypress_complete_donation&transaction_id=" . $transaction->getID() ),
				'cancelUrl'     => admin_url( "admin-post.php?action=charitypress_complete_donation&transaction_id=" . $transaction->getID() ),
			];

			$recurring = $transaction->getRecurring();
			if ( ! empty( $recurring ) ) {
				$args['intervalLength'] = $transaction->getRecurring()['interval_length'];
				$args['intervalUnit']   = $transaction->getRecurring()['interval_unit'];
			}

			/** @var \Omnipay\Common\Message\ResponseInterface $response */
			$response = $gateway->purchase( $args )->send();

			// Process response
			if ( $response->isSuccessful() ) {

				return new SuccessResponse( $response, $transaction, $ajax );

			} elseif ( $response->isRedirect() ) {

				// Redirect to offsite payment gateway
				$response->redirect();

			} else {

				return new FailureResponse( $response, $transaction, $ajax );
			}
		} catch ( \Exception $exception ) {
			wp_die( $exception->getMessage() );
		}

		die();
	}

	/**
	 * When an off-site transaction returns complete the purchase.
	 *
	 * @param Transaction $transaction
	 * @param GatewayInterface $gateway
	 *
	 * @return FailureResponse|SuccessResponse
	 */
	public static function complete( Transaction $transaction, GatewayInterface $gateway ) {

		try {

			/** @var \Omnipay\Common\Message\ResponseInterface $response */
			$response = $gateway->completePurchase( [
				'amount'   => $transaction->getAmount(),
				'currency' => $transaction->getCurrency()
			] )->send();

			if ( $response->isSuccessful() ) {

				return new SuccessResponse( $response, $transaction );

			} else {

				return new FailureResponse( $response, $transaction );

			}

		} catch ( \Exception $exception ) {
			wp_die( $exception->getMessage() );
		}

		die();

	}
}