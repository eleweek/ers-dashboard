<?php
namespace CharityPressDonations\Library;


class DonationsQuery {

	/** @var string */
	protected $orderby = 'id DESC';

	/** @var string */
	protected $page = '1';

	/** @var string */
	protected $perPage = '10';

	/** @var string */
	protected $offset = '0';

	/** @var array  */
	protected $wheres = [];

	/** @var  Array */
	protected $columns;

	/** @var  array */
	protected $timeRange;

	function __construct( $table_name ) {
		$this->table = $table_name;

		$this->columns = [
			'id',
			'amount',
			'status',
			'created',
			'gateway',
			'gateway_transaction_id',
			"CASE WHEN recurring IS NOT NULL THEN 'True' ELSE 'False' END recurring",
			'donor',
			'extras',
			'gift_aid',
		];
	}

	/**
	 * @return string
	 */
	public function getOrderby() {
		return $this->orderby;
	}

	/**
	 * @param string $orderby
	 *
	 * @return DonationsQuery
	 */
	public function setOrderby( $orderby ) {
		if ( $orderby ) {
			$this->orderby = $orderby;
		}

		return $this;
	}

	/**
	 * @return string
	 */
	public function getPage() {
		return $this->page;
	}

	/**
	 * @return string
	 */
	public function getPerPage() {
		return $this->perPage;
	}

	/**
	 * @param string $perPage
	 *
	 * @return DonationsQuery
	 */
	public function setPerPage( $perPage ) {
		$this->perPage = $perPage;

		return $this;
	}

	/**
	 * @return string
	 */
	public function getOffset() {
		return $this->offset;
	}

	/**
	 * @param string $offset
	 *
	 * @return DonationsQuery
	 */
	public function setOffset( $offset ) {
		$this->offset = $offset;

		return $this;
	}

	/**
	 * @return mixed
	 */
	public function getTimeRange() {
		if ( $this->timeRange ) {
			return "WHERE `created` BETWEEN '{$this->timeRange['from']}' AND '{$this->timeRange['to']}'";
		}

		return $this->timeRange;
	}

	/**
	 * @param $timeRange
	 *
	 * @return DonationsQuery
	 */
	public function setTimeRange( array $timeRange = null ) {

		$this->timeRange = $timeRange;

		if ( $this->timeRange ) {
			$this->addWhere( 'created', "BETWEEN '{$this->timeRange['from']}' AND '{$this->timeRange['to']}'" );
		}

		return $this;
	}

	/**
	 * @param $page
	 *
	 * @return DonationsQuery
	 */
	public function setPage( $page ) {
		$this->page = $page;

		return $this;
	}

	public function addWhere( $column, $value ) {
		$this->wheres[$column] = $value;
	}

	public function getWheres() {
		if(empty($this->wheres)){
			return "";
		}

		$wheres = [];
		foreach ($this->wheres as $column => $value){
			$wheres[] = "$column $value";
		}
		return 'WHERE ' . implode(' AND ', $wheres);
	}

	/**
	 * @return array
	 */
	public function toArray() {
		$args = [
			'page'    => $this->page,
			'perPage' => $this->perPage,
			'offset'  => $this->offset,
			'orderby' => $this->orderby
		];

		if ( $this->timeRange ) {
			$args['from'] = $this->timeRange['from'];
			$args['to']   = $this->timeRange['to'];
		}

		return $args;
	}

	/**
	 * @return array
	 */
	public function getColumns() {
		return $this->columns;
	}

	private function getSQL() {
		/** @var \wpdb $wpdb */
		global $wpdb;
		$wpdb->hide_errors();

		$columns = implode( ', ', $this->getColumns() );

		return "SELECT SQL_CALC_FOUND_ROWS
			{$columns}
			FROM `{$this->table}`
			{$this->getWheres()}
			ORDER BY {$this->getOrderby()}
			LIMIT {$this->getOffset()}, {$this->getPerPage()};";
	}

	private function getResults() {
		global $wpdb;

		$results = $wpdb->get_results( $this->getSQL(), ARRAY_A );
		$return  = [ ];
		foreach ( $results as $result ) {
			$return[] = new Transaction( $result );
		}

		return $return;
	}

	private function getSumTotal() {
		global $wpdb;

		$this->columns = [ 'sum(amount) as sum' ];
		$this->setPage( 1 )
		     ->setPerPage( 9223372036854775807 )
		     ->setOffset( 0 );

		return $wpdb->get_var( $this->getSQL() );
	}

	public function run() {
		/** @var \wpdb $wpdb */
		global $wpdb;

		return [
			'records'          => $this->getResults(),
			'error'            => $wpdb->last_error,
			'query'            => $wpdb->last_query, // always set before doing 'select found rows'
			'columns'          => $wpdb->get_col_info( 'name', - 1 ),
			'totalRecordCount' => (int) $wpdb->num_rows,
			'queryRecordCount' => (int) $wpdb->get_var( 'SELECT FOUND_ROWS()' ),
			'args'             => $this->toArray(),
			'sum'              => $this->getSumTotal()
		];
	}
}