<?php $default_columns = [
	[ 'title' => 'Amount' ],
	[ 'title' => 'Status' ],
	[ 'title' => 'Created' ],
	[ 'title' => 'Donor', 'sortable' => false ],
	[ 'title' => 'Gateway' ],
	[ 'title' => 'Gateway Transaction ID' ],
	[ 'title' => 'Gift Aid' ],
]; ?>

<div class='wrap'>
	<h2><?php echo get_admin_page_title(); ?></h2>

	<label>
		From: <input type="text" id="from" placeholder="dd/mm/yyyy" data-dynatable-query="from"/>&nbsp;
		To: <input type="text" id="to" placeholder="dd/mm/yyyy" data-dynatable-query="to"/>
		<a class="clear button" href="#">Clear</a>
	</label>

	<label>
		<span>Status:</span>
		<select name="status" id="search-status">
			<option value="">All</option>
			<option value="success">Success</option>
			<option value="fail">Fail</option>
			<option value="pending">Pending</option>
		</select>
	</label>

	<table id="donations-table" class="widefat">
		<thead>
		<tr>
			<?php
			foreach ( apply_filters( 'charitypress/donations/report_columns', $default_columns ) as $column ) {
				$sortable = ( isset( $column['sortable'] ) && $column['sortable'] == false ) ? 'data-dynatable-no-sort="true"' : "";
				echo sprintf( '<th %s>%s</th>', $sortable, $column['title'] );
			}
			?>
		</tr>
		</thead>
		<tbody></tbody>
	</table>

	<form action="<?php echo site_url( 'wp-admin/admin-post.php' ); ?>" method="POST" class="export">
		<input type="hidden" name="action" value="charitypress-donations-generate-csv"/>
		<button id="export" class="button">Export this query</button>
	</form>

</div>
