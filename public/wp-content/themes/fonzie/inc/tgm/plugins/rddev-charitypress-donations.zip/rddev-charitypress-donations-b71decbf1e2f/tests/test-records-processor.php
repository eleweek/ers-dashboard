<?php

class TestRecordsProcessor extends WP_UnitTestCase {

	public function test_process_records_run() {

		$default_fields = [
			'amount'                 => 'amount',
			'status'                 => 'status',
			'created'                => 'created',
			'donor'                  => function ( $record ) {
				$donor = $record->getDonor();

				$donor['firstName'] .= " " . $donor['lastName'];
				unset( $donor['lastName'] );

				$donor = array_filter( $donor );

				return implode( ', ', $donor );
			},
			'gateway'                => 'gateway',
			'gateway_transaction_id' => 'gateway_transaction_id',
			'gift_aid'               => 'gift_aid',
		];

		$transaction = new \CharityPressDonations\Library\Transaction( [
			'id'      => 2,
			'gateway' => "Stripe",
			'status'  => 'success',
			'amount'  => '7.50',
			'created' => '2016-04-18 11:41:29',
			'donor'   => [
				"title"           => "",
				"firstName"       => "Merritt",
				"lastName"        => "Bird",
				"billingAddress1" => "Et minus quia voluptate id tenetur sed sit dicta recusandae Itaque exercitationem sint fugiat sed excepteur beatae sunt sit tenetur",
				"billingAddress2" => "",
				"billingCity"     => "Town",
				"billingPostcode" => "M11DW",
				"billingState"    => "Manchester",
				"billingCountry"  => "GB",
				"billingPhone"    => "",
				"email"           => "xuhywy@gmail.com"
			]
		] );

		$transactions = [ $transaction ];
		$result       = \CharityPressDonations\Library\RecordProcessor::process( $transactions, $default_fields );

		$expected = [
			[
				'amount'                 => '7.50',
				'status'                 => 'success',
				'created'                => '2016-04-18 11:41:29',
				'donor'                  => "Merritt Bird, Et minus quia voluptate id tenetur sed sit dicta recusandae Itaque exercitationem sint fugiat sed excepteur beatae sunt sit tenetur, Town, M11DW, Manchester, GB, xuhywy@gmail.com",
				'gateway'                => 'Stripe',
				'gateway_transaction_id' => null,
				'gift_aid'               => false,
			]
		];

		$this->assertEquals( $expected, $result );

	}
}