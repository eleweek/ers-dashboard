<?php namespace CharityPressDonations\Library;

class RecordProcessor {

	/**
	 * @var array
	 */
	private $records;
	/**
	 * @var array
	 */
	private $fields;

	/**
	 * RecordProcessor constructor.
	 *
	 * @param array $records
	 * @param array $fields
	 */
	public function __construct( array $records, array $fields ) {
		$this->records = $records;
		$this->fields  = $fields;
	}

	public function run() {
		$processed = [ ];

		foreach ( $this->records as $index => $record ) {
			foreach ( $this->fields as $key => $field ) {

				if ( $field instanceof \Closure ) {
					$processed[ $index ][ $key ] = $field( $record );
					continue;
				}

				$pieces = explode( '.', $field );
				$temp   = $record->toArray();
				foreach ( $pieces as $piece ) {
					$temp = &$temp[ $piece ];
				}
				$processed[ $index ][ $key ] = $temp;
			}
		}

		return $processed;
	}

	public static function process( array $records, array $fields ) {
		return ( new self( $records, $fields ) )->run();
	}
}