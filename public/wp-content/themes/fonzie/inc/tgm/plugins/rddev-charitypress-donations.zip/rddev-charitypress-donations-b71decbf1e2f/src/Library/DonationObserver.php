<?php namespace CharityPressDonations\Library;

use Omnipay\Common\CreditCard;

class DonationObserver {

	function __construct( $nonce_string, $db_table_name ) {
		$this->nonce_string  = $nonce_string;
		$this->db_table_name = $db_table_name;
	}

	public function init() {

		// Catch when donation form is submitted
		add_action( 'admin_post_charitypress_donate', [ $this, 'receiveDonation' ] );
		add_action( 'admin_post_nopriv_charitypress_donate', [ $this, 'receiveDonation' ] );
		add_action( 'wp_ajax_charitypress_donate', [ $this, 'receiveDonation' ] );
		add_action( 'wp_ajax_nopriv_charitypress_donate', [ $this, 'receiveDonation' ] );

		// Ajax form validation
		add_action( 'wp_ajax_charitypress_validate_form', [ $this, 'validateForm' ] );
		add_action( 'wp_ajax_nopriv_charitypress_validate_form', [ $this, 'validateForm' ] );

		// Catch offsite transaction return
		add_action( 'admin_post_charitypress_complete_donation', [ $this, 'completeDonation' ] );
		add_action( 'admin_post_nopriv_charitypress_complete_donation', [ $this, 'completeDonation' ] );
	}

	public function receiveDonation() {

		// Check whether this is an ajax call, and if so that we have a proper nonce
		$ajax = false;
		if ( defined( 'DOING_AJAX' ) ) {
			if ( ! check_ajax_referer( $this->nonce_string, 'security', false ) ) {
				wp_send_json( [ 'error' => "We don't accept no noncesense round here!" ] );
			}
			$ajax = true;
		}

		// Create new transaction in the database
		$transaction = Transaction::create( $_POST, $this->db_table_name );

		do_action( 'charitypress/donations/donation/start', $transaction );

		// Instantiate new card object for use in the donation
		$card = new CreditCard( $this->addDefaults( $_POST['card'] ) );

		// Create Gateway object
		$gateway = Gateway::make( $transaction->getGateway() );

		// Transact the donation
		$response = Donation::make( $transaction, $card, $gateway, $ajax );
		$response->run();

	}

	public function completeDonation() {

		// Find transaction in db
		$transaction = Transaction::find( $_GET['transaction_id'], $this->db_table_name );

		// Create Gateway object
		$gateway = Gateway::make( $transaction->getGateway() );

		$response = Donation::complete( $transaction, $gateway );

		do_action( 'charitypress/donations/donation/complete', $transaction, $response );

		$response->run();

	}

	public function validateForm() {

		parse_str( $_POST['formdata'], $formdata );

		if ( ! empty( $formdata['card'] ) ) {
			foreach ( $formdata['card'] as $key => $value ) {
				$formdata[ $key ] = $value;
			}
		}

		$validation = new Validator( $formdata );
		$response   = [ 'valid' => true, 'errors' => [ ] ];

		if ( ! $validation->valid() ) {
			$response['valid']  = false;
			$response['errors'] = $validation->errors();
		}

		wp_send_json( $response );
	}

	function addDefaults( &$card ) {
		$defaults = [
			'billingCountry' => 'GB'
		];

		return array_merge( $defaults, $card );
	}
}
