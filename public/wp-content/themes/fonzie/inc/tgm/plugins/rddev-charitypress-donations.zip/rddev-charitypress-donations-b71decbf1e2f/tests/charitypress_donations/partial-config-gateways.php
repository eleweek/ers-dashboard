<?php

return [
	'GoCardless' => [
		'appId' => 'rndmstuff8888',
		'appSecret' => 'rndmstooff00029292',
	],
];