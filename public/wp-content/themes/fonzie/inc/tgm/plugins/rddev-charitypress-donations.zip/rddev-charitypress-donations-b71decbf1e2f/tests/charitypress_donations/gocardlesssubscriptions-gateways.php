<?php

return [
	'GoCardlessSubscription' => [
		'appId' => 'rndmstuff8888',
		'appSecret' => 'rndmstooff00029292',
		'merchantId' => '',
		'accessToken' => '',
		'testMode' => true
	],
];