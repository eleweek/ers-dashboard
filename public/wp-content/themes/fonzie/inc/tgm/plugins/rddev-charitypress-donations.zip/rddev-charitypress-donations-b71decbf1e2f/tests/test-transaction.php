<?php

class TestTransaction extends WP_UnitTestCase {

	function setUp() {
		parent::setUp();
	}

	function testIntegerAmountGetsSetToFloat () {
		$transaction = new \CharityPressDonations\Library\Transaction(['amount' => 12], 'wp_charitypress_donations');

		$this->assertTrue($transaction->getAmount() === '12.00');
	}

	function testFloatAmountRemainsFloat () {
		$transaction = new \CharityPressDonations\Library\Transaction(['amount' => 24.42], 'wp_charitypress_donations');

		$this->assertTrue($transaction->getAmount() === '24.42');
	}

}