<div class="wrap">
	<h2><?php echo get_admin_page_title(); ?></h2>
	<?php settings_errors(); ?>

	<form method="post" action="options.php">
		<?php
		settings_fields( 'cp_donations_email_confirmation_settings' );
		do_settings_sections( 'cp_donations_email_settings' );
		submit_button();
		?>
	</form>

</div>