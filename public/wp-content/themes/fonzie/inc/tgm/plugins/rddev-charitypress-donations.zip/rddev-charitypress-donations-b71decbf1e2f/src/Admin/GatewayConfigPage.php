<?php namespace CharityPressDonations\Admin;

use CharityPressDonations\Helpers;
use Omnipay\Omnipay;

class GatewayConfigPage {

	function __construct( $dashboardUrl, $path ) {
		$this->dashboardUrl = $dashboardUrl;
		$this->views        = $path . 'views/';

		$this->singleGateways = array_map( function ( $name ) {
			return Omnipay::create( $name );
		}, Helpers::getSingleGateways() );

		$this->recurringGateways = array_map( function ( $name ) {
			return Omnipay::create( $name );
		}, Helpers::getRecurringGateways() );
	}

	public function init() {
		add_action( 'admin_init', [ $this, 'settingsInit' ] );
		add_action( 'admin_menu', [ $this, 'addSubMenuPage' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueueScripts' ] );
		add_action( 'wp_ajax_cp_get_gateway_parameters', [ $this, 'getGatewayConfigParameters' ] );
	}

	public function settingsInit() {
		add_settings_section(
			'cp_gateway_setup',
			'Gateway Parameters Section',
			[ $this, 'gatewaySectionRender' ],
			'cp_page_cp_gateway_setup'
		);

		add_settings_field(
			'single_gateway',
			'Single Gateway',
			[ $this, 'singleGatewayFormRender' ],
			'cp_page_cp_gateway_setup',
			'cp_gateway_setup'
		);

		add_settings_field(
			'recurring_gateway',
			'Recurring Gateway',
			[ $this, 'recurringGatewayFormRender' ],
			'cp_page_cp_gateway_setup',
			'cp_gateway_setup'
		);

		register_setting( 'cp_gateway_setup', 'single_gateway' );
		register_setting( 'cp_gateway_setup', 'recurring_gateway' );
	}

	public function gatewaySectionRender() {
		echo '';
	}

	public function singleGatewayFormRender() {
		$saved_gateway = get_option( 'single_gateway' );
		?>
		<select name="single_gateway[shortname]" data-frequency="single" class="gateway_selector">
			<option value="">Select&hellip;</option>
			<?php /** @var \Omnipay\Common\AbstractGateway $gateway */
			foreach ( $this->singleGateways as $gateway ) {
				echo sprintf(
					'<option value="%s"%s>%s</option>',
					$gateway->getShortName(),
					( ! empty( $saved_gateway['shortname'] ) && $saved_gateway['shortname'] == $gateway->getShortName() ) ? ' selected' : '',
					$gateway->getName()
				);
			} ?>
		</select>

		<table class="form-table single_parameters">
			<?php if ( ! empty( $saved_gateway['parameters'] ) ) {
				$this->outputSavedParameterFields( $saved_gateway, 'single' );
			} ?>
		</table>
		<?php
	}

	public function recurringGatewayFormRender() {
		/** @var array $saved_gateway */
		$saved_gateway = get_option( 'recurring_gateway', [ ] );
		?>
		<select name="recurring_gateway[shortname]" data-frequency="recurring" class="gateway_selector">
			<option value="">Select&hellip;</option>
			<?php /** @var \Omnipay\Common\AbstractGateway $gateway */
			foreach ( $this->recurringGateways as $gateway ) {
				echo sprintf(
					'<option value="%s"%s>%s</option>',
					$gateway->getShortName(),
					( ! empty( $saved_gateway['shortname'] ) && $gateway->getShortName() == $saved_gateway['shortname'] ) ? ' selected' : '',
					$gateway->getName()
				);
			} ?>
		</select>

		<table class="form-table recurring_parameters">
			<?php if ( ! empty( $saved_gateway['parameters'] ) ) {
				$this->outputSavedParameterFields( $saved_gateway, 'recurring' );
			} ?>
		</table>
		<?php
	}

	public function enqueueScripts() {
		wp_enqueue_script( 'underscore', false, [ ], false, false );
	}

	public function addSubMenuPage() {
		add_submenu_page(
			'charitypress-donations-reports',
			'Gateway Setup',
			'Gateway Setup',
			'manage_options',
			'cp-gateway-settings',
			[ $this, 'outputPage' ]
		);
	}

	public function outputPage() {
		include_once $this->views . 'gateway-setup-view.php';
	}

	public function getGatewayConfigParameters() {
		if ( empty( $_POST['gateway_name'] ) ) {
			wp_send_json( [ ] );
		}

		$name = $_POST['gateway_name'];

		$parameters = Omnipay::create( $name )->getDefaultParameters();

		wp_send_json( $parameters );
	}

	private function outputSavedParameterFields( $gateway, $frequency ) {
		$defaultParameters = Omnipay::create( $gateway['shortname'] )->getDefaultParameters();
		foreach ( $gateway['parameters'] as $index => $value ) :
			if (is_array($defaultParameters[$index])) {
				$type = 'select';
			} else if ('true' == $value || 'false' == $value) {
				$type = 'checkbox';
			} else {
				$type = 'text';
			}

			$class = ( 'text' == $type ) ? 'regular-text' : '';
			?>
			<tr>
				<th scope="row"><label for="<?php echo $index; ?>"><?php echo $index; ?></label></th>
				<td>
					<?php if ( 'checkbox' == $type ): ?>
						<input type="hidden" name="<?php echo $frequency; ?>_gateway[parameters][<?php echo $index; ?>]"
						       value="false"/>
					<?php endif; ?>

					<?php if ( 'select' == $type ): ?>
						<select name="<?php echo $frequency; ?>_gateway[parameters][<?php echo $index; ?>]"
						        type="<?php echo $type; ?>"
						        id="<?php echo $index; ?>"
						        class="<?php echo $class; ?>"
						>
							<?php foreach($defaultParameters[$index] as $parameter): ?>
								<option value="<?php echo $parameter; ?>" <?php echo $parameter == $value ? 'selected="selected"' : ''; ?>><?php echo $parameter; ?></option>
							<?php endforeach; ?>
						</select>
					<?php else: ?>
						<input name="<?php echo $frequency; ?>_gateway[parameters][<?php echo $index; ?>]"
						       type="<?php echo $type; ?>"
						       id="<?php echo $index; ?>"
						       value="<?php echo ( 'checkbox' == $type ) ? 'true' : $value; ?>"
						       class="<?php echo $class; ?>"
							<?php echo ( 'checkbox' == $type && $value == 'true' ) ? 'checked' : ''; ?>
						>
					<?php endif; ?>
				</td>
			</tr>
		<?php endforeach;
	}

}