<?php

/*
Plugin Name: Reason Digital Tag Manager
Description: Just adds the GTM tag code
Version: 0.0.3
Author: Matthew Laver
*/

class RD_GTM_Tag {

	protected $gtmTag;

	public function __construct($tag = null) {
		if ($tag === null){
			$tag = get_option('rd_gtm_tag');
		}
		$this->gtmTag = $tag;
	}

	public function init() {
		add_action( 'admin_init', [ $this, 'registerSetting' ] );
		add_action( 'rd/gtm-tag', [ $this, 'renderTag' ] );
		add_filter( 'plugin_action_links_' . plugin_basename(__FILE__), [$this, 'addSettingsLink'] );
	}

	public function renderTag() {

		if ( ! $this->tagValid() ) {
			return false;
		}

		echo <<<TAG
<!-- Google Tag Manager -->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id={$this->gtmTag}"
height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
'//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
})(window,document,'script','dataLayer','{$this->gtmTag}');</script>
<!-- End Google Tag Manager -->
TAG;

	}

	public function registerSetting() {
		add_settings_field('rd_gtm_tag', 'GTM ID', [$this, 'outputSettings'], 'reading');
		register_setting( 'reading', 'rd_gtm_tag');
	}

	public function outputSettings(){
		echo "<input type='text' id='rd_gtm_tag' name='rd_gtm_tag' value='$this->gtmTag' />";
	}

	public function addSettingsLink($links) {
		$gtmLinks = [
			'<a href="' . admin_url( 'options-reading.php#rd_gtm_tag' ) . '">Settings</a>',
		];
		return array_merge( $links, $gtmLinks  );
	}

	private function tagValid() {
		if (empty($this->gtmTag)){
			return false;
		}

		return true;
	}
}

(new RD_GTM_Tag)->init();